$(document).ready(function(){
   /*For the sticky navigation*/
    $ ('.section-features,.js--section-features').waypoint(function(direction){
       if(direction=="down"){
           $('nav');
           $(this).addClass('sticky');
       } 
        else{
            $('nav');
            $(this).removeClass('sticky');
        }
    },{
        offset: '60px;'
        
    });
    
    
    /*scroll on button*/
    $('.js--scroll-to-start').click(function(){
        $('html,body').animate({scrollTop: $('.js--section-features').offset().top},1000);
    });
    
    
});
